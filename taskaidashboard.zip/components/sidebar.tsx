import { Home, ShoppingCart, Activity, User, FileText } from "lucide-react"

export function Sidebar() {
  return (
    <div className="w-16 bg-[#1e1e24] flex flex-col items-center py-6 border-r border-gray-800">
      <div className="w-8 h-8 bg-blue-600 flex items-center justify-center rounded mb-8">
        <span className="text-xs font-bold">AI</span>
      </div>

      <nav className="flex flex-col items-center gap-6 flex-1">
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <Home size={20} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <ShoppingCart size={20} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <Activity size={20} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <User size={20} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <FileText size={20} />
        </button>
      </nav>
    </div>
  )
}
