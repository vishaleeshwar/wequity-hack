"use client"

import { useState, useEffect } from "react"
import { Volume2, VolumeX } from "lucide-react"

interface TextToSpeechProps {
  text: string
}

export function TextToSpeech({ text }: TextToSpeechProps) {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isSupported, setIsSupported] = useState(true)

  useEffect(() => {
    // Check if the browser supports the Web Speech API
    if (typeof window !== "undefined" && !("speechSynthesis" in window)) {
      setIsSupported(false)
    }
  }, [])

  const speak = () => {
    if (!isSupported || !text) return

    // Stop any ongoing speech
    window.speechSynthesis.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    window.speechSynthesis.speak(utterance)
  }

  const stop = () => {
    if (!isSupported) return
    window.speechSynthesis.cancel()
    setIsSpeaking(false)
  }

  if (!isSupported) return null

  return (
    <button
      type="button"
      onClick={isSpeaking ? stop : speak}
      className={`p-1.5 rounded-full ${isSpeaking ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"}`}
      title={isSpeaking ? "Stop speaking" : "Speak text"}
    >
      {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
    </button>
  )
}
