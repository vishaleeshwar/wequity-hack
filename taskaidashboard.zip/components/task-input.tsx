import { Plus } from "lucide-react"

export function TaskInput() {
  return (
    <div className="bg-[#1e1e24] rounded-full p-2 pl-6 pr-2 flex items-center justify-between mb-8">
      <div className="text-sm font-medium">TASK</div>
      <div className="flex items-center gap-2">
        <input
          type="text"
          placeholder="TASK NAME"
          className="bg-transparent border-none outline-none text-sm text-white placeholder-gray-500"
        />
        <button className="w-6 h-6 rounded-full bg-white text-black flex items-center justify-center">
          <Plus size={16} />
        </button>
      </div>
    </div>
  )
}
