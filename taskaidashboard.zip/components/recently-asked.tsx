"use client"

import { Calendar, FileText, Bell } from "lucide-react"
import { useState } from "react"
import { TextToSpeech } from "./text-to-speech"

export function RecentlyAsked() {
  const [tasks] = useState([
    {
      id: 1,
      icon: <Calendar className="h-4 w-4" />,
      text: "Schedule meeting with marketing team",
      time: "2h ago",
    },
    {
      id: 2,
      icon: <FileText className="h-4 w-4" />,
      text: "Create project report summary",
      time: "10h ago",
    },
    {
      id: 3,
      icon: <Bell className="h-4 w-4" />,
      text: "Set reminder for team meeting",
      time: "1d ago",
    },
  ])

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-sm font-medium">Recently Asked</h2>
        <button className="text-xs text-blue-500">See all</button>
      </div>

      <div className="bg-[#2a2a30] rounded-lg overflow-hidden">
        {tasks.map((task, index) => (
          <div
            key={task.id}
            className={`flex items-center justify-between p-4 ${
              index < tasks.length - 1 ? "border-b border-gray-700" : ""
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-[#3a3a3e] rounded-full flex items-center justify-center text-gray-400">
                {task.icon}
              </div>
              <span className="text-sm">{task.text}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">{task.time}</span>
              <TextToSpeech text={task.text} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
